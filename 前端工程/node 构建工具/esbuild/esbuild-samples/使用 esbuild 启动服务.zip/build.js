// require('esbuild').build({
//   entryPoints: ['src/app.js'],
//   outdir: 'www/js',
//   bundle: true,
// }).catch(() => process.exit(1))

require('esbuild').serve({
  servedir: 'www',
}, {
  entryPoints: ['src/app.js'],
  outdir: 'www/js',
  bundle: true,
}).then(server => {
  console.log(server);
  // Call "stop" on the web server when you're done
  // server.stop()
}).catch(e => {
  console.error(e);
})