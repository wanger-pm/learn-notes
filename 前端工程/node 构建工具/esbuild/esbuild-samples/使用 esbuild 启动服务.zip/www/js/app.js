(() => {
  // src/app.js
  document.body.innerHTML = "<div>M123</div>";
})();
